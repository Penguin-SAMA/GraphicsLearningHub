#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <limits>

const double infinity = std::numeric_limits<double>::infinity();

#endif
